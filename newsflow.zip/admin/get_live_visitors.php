<?php
require_once 'config.php';

$live_visitors_count = 0;
$result = $conn->query("SELECT COUNT(*) as live FROM visitors WHERE last_visit >= NOW() - INTERVAL 5 MINUTE");
if ($result) {
    $live_visitors_count = $result->fetch_assoc()['live'];
}

header('Content-Type: application/json');
echo json_encode(['live_visitors' => $live_visitors_count]);
?>