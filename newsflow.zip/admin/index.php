<?php
// --- SETUP AND ROUTING ---
require_once '../config.php'; // Go up one directory to find config.php

// --- SETUP AND ROUTING ---
// session_start(); // Start the session to access login state

// --- SECURITY CHECK ---
// If the user is not logged in, redirect them to the login page
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: index.php");
    exit;
}

require_once '../config.php'; // Go up one directory to find config.php
// ... rest of your admin/index.php file
// Start session if not already started (config.php should handle this)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// --- LOGOUT LOGIC ---
if (isset($_GET['action']) && $_GET['action'] == 'logout') {
    session_destroy();
    header("Location: ../login.php"); // Redirect to the homepage
    exit;
}

// --- DYNAMIC PAGE ROUTING ---
// Determine which page to display. Default to the dashboard.
$page = $_GET['page'] ?? 'dashboard';

// --- SHARED DATA FETCHING ---
$all_categories = $conn->query("SELECT * FROM categories ORDER BY name ASC")->fetch_all(MYSQLI_ASSOC);

// --- FORM HANDLING LOGIC (ADD/EDIT/DELETE) ---

// ARTICLES
if ($page == 'articles' && isset($_POST['action'])) {
    $title = $_POST['title'] ?? '';
    $content = $_POST['content'] ?? '';
    $author = $_POST['author'] ?? '';
    $category_id = $_POST['category_id'] ?? 0;
    $id = $_POST['id'] ?? 0;
    $current_image = $_POST['current_image'] ?? '';
    $image_name = $current_image;

    // Handle image upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $target_dir = "../uploads/";
        $image_name = uniqid() . '-' . basename($_FILES["image"]["name"]);
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_dir . $image_name)) {
            // If a new image is uploaded for an existing article, delete the old one
            if ($_POST['action'] == 'edit' && !empty($current_image) && file_exists($target_dir . $current_image)) {
                unlink($target_dir . $current_image);
            }
        } else {
            $image_name = $current_image; // Revert to old image if upload fails
        }
    }

    if ($_POST['action'] == 'add') {
        $stmt = $conn->prepare("INSERT INTO articles (title, content, author, category_id, image) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssis", $title, $content, $author, $category_id, $image_name);
        $_SESSION['message'] = "Article added successfully!";
    } elseif ($_POST['action'] == 'edit' && $id) {
        $stmt = $conn->prepare("UPDATE articles SET title = ?, content = ?, author = ?, category_id = ?, image = ? WHERE id = ?");
        $stmt->bind_param("sssisi", $title, $content, $author, $category_id, $image_name, $id);
        $_SESSION['message'] = "Article updated successfully!";
    }
    
    if (isset($stmt) && $stmt->execute()) {
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Error performing action.";
        $_SESSION['message_type'] = "error";
    }
    if(isset($stmt)) $stmt->close();
    header("Location: index.php?page=articles");
    exit;
}

// DELETE ARTICLE
if ($page == 'articles' && isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    // First, get the image filename to delete the file
    $image_res = $conn->query("SELECT image FROM articles WHERE id = $id");
    if ($image_res->num_rows > 0) {
        $image_to_delete = $image_res->fetch_assoc()['image'];
        if ($image_to_delete && file_exists('../uploads/' . $image_to_delete)) {
            unlink('../uploads/' . $image_to_delete);
        }
    }
    $conn->query("DELETE FROM articles WHERE id = $id");
    $_SESSION['message'] = "Article deleted successfully!";
    $_SESSION['message_type'] = "success";
    header("Location: index.php?page=articles");
    exit;
}

// CATEGORIES
if ($page == 'categories' && isset($_POST['action'])) {
    $name = $_POST['name'] ?? '';
    $id = $_POST['id'] ?? 0;

    if ($_POST['action'] == 'add') {
        $stmt = $conn->prepare("INSERT INTO categories (name) VALUES (?)");
        $stmt->bind_param("s", $name);
        $_SESSION['message'] = "Category added successfully!";
    } elseif ($_POST['action'] == 'edit' && $id) {
        $stmt = $conn->prepare("UPDATE categories SET name = ? WHERE id = ?");
        $stmt->bind_param("si", $name, $id);
        $_SESSION['message'] = "Category updated successfully!";
    }

    if (isset($stmt) && $stmt->execute()) {
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Error performing action.";
        $_SESSION['message_type'] = "error";
    }
    if(isset($stmt)) $stmt->close();
    header("Location: index.php?page=categories");
    exit;
}

// DELETE CATEGORY
if ($page == 'categories' && isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $conn->query("DELETE FROM categories WHERE id = $id");
    $_SESSION['message'] = "Category deleted successfully!";
    $_SESSION['message_type'] = "success";
    header("Location: index.php?page=categories");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NewsFlow Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        .sidebar { transition: transform 0.3s ease-in-out; }
    </style>
</head>
<body class="bg-gray-100 font-poppins">
    <div class="flex min-h-screen">
        <!-- Overlay for mobile menu -->
        <div id="sidebar-overlay" class="fixed inset-0 bg-black/50 z-30 hidden lg:hidden"></div>

        <!-- Sidebar -->
        <aside id="sidebar" class="sidebar fixed top-0 left-0 h-full w-64 bg-gray-800 text-white flex-shrink-0 z-40 transform -translate-x-full lg:translate-x-0">
            <div class="p-5 text-2xl font-bold border-b border-gray-700 flex justify-between items-center">
                <a href="index.php">News<span class="text-blue-500">Flow</span></a>
                <button id="close-sidebar-btn" class="lg:hidden text-gray-400 hover:text-white"><i class="fas fa-times"></i></button>
            </div>
            <nav class="mt-6">
                <a href="index.php?page=dashboard" class="flex items-center px-6 py-3 <?php echo $page == 'dashboard' ? 'bg-gray-700' : 'hover:bg-gray-700'; ?>">
                    <i class="fas fa-tachometer-alt w-6"></i><span class="ml-4">Dashboard</span>
                </a>
                <a href="index.php?page=articles" class="flex items-center px-6 py-3 <?php echo $page == 'articles' ? 'bg-gray-700' : 'hover:bg-gray-700'; ?>">
                    <i class="fas fa-newspaper w-6"></i><span class="ml-4">Articles</span>
                </a>
                <a href="index.php?page=categories" class="flex items-center px-6 py-3 <?php echo $page == 'categories' ? 'bg-gray-700' : 'hover:bg-gray-700'; ?>">
                    <i class="fas fa-tags w-6"></i><span class="ml-4">Categories</span>
                </a>
                <a href="index.php?page=visitors" class="flex items-center px-6 py-3 <?php echo $page == 'visitors' ? 'bg-gray-700' : 'hover:bg-gray-700'; ?>">
                    <i class="fas fa-users w-6"></i><span class="ml-4">Visitors</span>
                </a>
                <!-- Add this link in admin/index.php -->
<a href="manage_contact.php" class="flex items-center px-6 py-3 text-gray-300 hover:bg-gray-700">
    <i class="fas fa-envelope-open-text w-6"></i>
    <span class="ml-4">Contact Messages</span>
</a>
                <div class="mt-8 border-t border-gray-700">
                    <a href="../index.php" target="_blank" class="flex items-center px-6 py-3 hover:bg-gray-700">
                        <i class="fas fa-external-link-alt w-6"></i><span class="ml-4">View Live Site</span>
                    </a>
                    <a href="logout.php?action=logout" class="flex items-center px-6 py-3 hover:bg-gray-700">
                        <i class="fas fa-sign-out-alt w-6"></i><span class="ml-4">Logout</span>
                    </a>
                </div>
            </nav>
        </aside>

        <!-- Main Content Wrapper -->
        <div class="flex-1 lg:pl-64">
            <header class="bg-white shadow-md p-4 flex items-center justify-between lg:justify-end">
                <button id="open-sidebar-btn" class="lg:hidden text-gray-600 text-2xl">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="text-gray-600">Admin Panel</div>
            </header>

            <main class="p-6 md:p-8">
                <?php // --- PAGE CONTENT SWITCH ---
                switch ($page):
                    // --- DASHBOARD PAGE ---
                    case 'dashboard':
                        $total_articles = $conn->query("SELECT COUNT(*) as count FROM articles")->fetch_assoc()['count'];
                        $total_categories = $conn->query("SELECT COUNT(*) as count FROM categories")->fetch_assoc()['count'];
                        $total_visitors = $conn->query("SELECT COUNT(*) as count FROM visitors")->fetch_assoc()['count'];
                        $live_visitors = $conn->query("SELECT COUNT(*) as count FROM visitors WHERE last_visit >= NOW() - INTERVAL 5 MINUTE")->fetch_assoc()['count'];
                ?>
                    <h1 class="text-3xl font-bold text-gray-800 mb-8">Dashboard</h1>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        <div class="bg-white p-6 rounded-lg shadow-md flex items-center"><div class="bg-green-500 text-white p-4 rounded-full mr-4"><i class="fas fa-satellite-dish fa-2x"></i></div><div><h2 class="text-gray-500">Live Visitors</h2><p id="live-visitors" class="text-4xl font-bold"><?php echo $live_visitors; ?></p></div></div>
                        <div class="bg-white p-6 rounded-lg shadow-md flex items-center"><div class="bg-blue-500 text-white p-4 rounded-full mr-4"><i class="fas fa-users fa-2x"></i></div><div><h2 class="text-gray-500">Total Visitors</h2><p class="text-4xl font-bold"><?php echo $total_visitors; ?></p></div></div>
                        <div class="bg-white p-6 rounded-lg shadow-md flex items-center"><div class="bg-purple-500 text-white p-4 rounded-full mr-4"><i class="fas fa-newspaper fa-2x"></i></div><div><h2 class="text-gray-500">Total Articles</h2><p class="text-4xl font-bold"><?php echo $total_articles; ?></p></div></div>
                        <div class="bg-white p-6 rounded-lg shadow-md flex items-center"><div class="bg-yellow-500 text-white p-4 rounded-full mr-4"><i class="fas fa-tags fa-2x"></i></div><div><h2 class="text-gray-500">Total Categories</h2><p class="text-4xl font-bold"><?php echo $total_categories; ?></p></div></div>
                    </div>
                <?php break;

                    // --- ARTICLES PAGE ---
                    case 'articles':
                        $action = $_GET['action'] ?? 'list';
                        if ($action == 'add' || $action == 'edit'):
                            $article = ['id' => '', 'title' => '', 'content' => '', 'author' => '', 'category_id' => '', 'image' => ''];
                            if ($action == 'edit' && isset($_GET['id'])) {
                                $id = intval($_GET['id']);
                                $stmt = $conn->prepare("SELECT * FROM articles WHERE id = ?");
                                $stmt->bind_param("i", $id);
                                $stmt->execute();
                                $article = $stmt->get_result()->fetch_assoc();
                            }
                ?>
                            <h1 class="text-3xl font-bold text-gray-800 mb-8"><?php echo ucfirst($action); ?> Article</h1>
                            <div class="bg-white p-6 rounded-lg shadow-md">
                                <form action="index.php?page=articles" method="POST" enctype="multipart/form-data">
                                    <input type="hidden" name="action" value="<?php echo $action; ?>">
                                    <input type="hidden" name="id" value="<?php echo $article['id']; ?>">
                                    <input type="hidden" name="current_image" value="<?php echo $article['image']; ?>">
                                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                                        <div class="md:col-span-2 space-y-4">
                                            <div><label class="block font-semibold">Title</label><input type="text" name="title" value="<?php echo htmlspecialchars($article['title']); ?>" class="w-full p-2 border rounded" required></div>
                                            <div><label class="block font-semibold">Content</label><textarea name="content" rows="12" class="w-full p-2 border rounded" required><?php echo htmlspecialchars($article['content']); ?></textarea></div>
                                        </div>
                                        <div class="space-y-4">
                                            <div><label class="block font-semibold">Author</label><input type="text" name="author" value="<?php echo htmlspecialchars($article['author']); ?>" class="w-full p-2 border rounded" required></div>
                                            <div><label class="block font-semibold">Category</label><select name="category_id" class="w-full p-2 border rounded" required><option value="">Select...</option><?php foreach($all_categories as $cat): ?><option value="<?php echo $cat['id']; ?>" <?php if($cat['id']==$article['category_id']) echo 'selected'; ?>><?php echo htmlspecialchars($cat['name']); ?></option><?php endforeach; ?></select></div>
                                            <div><label class="block font-semibold">Featured Image</label><?php if($action=='edit' && $article['image']): ?><img src="../uploads/<?php echo $article['image']; ?>" class="w-full h-auto rounded mb-2"><?php endif; ?><input type="file" name="image" class="w-full p-2 border rounded"></div>
                                        </div>
                                    </div>
                                    <div class="mt-6"><button type="submit" class="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600">Save Article</button><a href="index.php?page=articles" class="ml-4 text-gray-600">Cancel</a></div>
                                </form>
                            </div>
                        <?php else: 
                            $articles = $conn->query("SELECT a.id, a.title, c.name AS category_name, a.author, a.created_at FROM articles a JOIN categories c ON a.category_id = c.id ORDER BY a.created_at DESC")->fetch_all(MYSQLI_ASSOC);
                        ?>
                            <div class="flex justify-between items-center mb-8"><h1 class="text-3xl font-bold text-gray-800">Manage Articles</h1><a href="index.php?page=articles&action=add" class="bg-blue-500 text-white font-semibold px-4 py-2 rounded-lg hover:bg-blue-600"><i class="fas fa-plus mr-2"></i>Add New</a></div>
                            <?php if (isset($_SESSION['message'])): ?><div class="mb-4 p-3 rounded <?php echo $_SESSION['message_type'] == 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>"><?php echo $_SESSION['message']; unset($_SESSION['message'], $_SESSION['message_type']); ?></div><?php endif; ?>
                            <div class="bg-white p-4 rounded-lg shadow-md overflow-x-auto"><table class="w-full"><thead><tr class="border-b"><th class="p-3 text-left">Title</th><th class="p-3 text-left">Category</th><th class="p-3 text-left hidden md:table-cell">Author</th><th class="p-3 text-left">Actions</th></tr></thead><tbody>
                            <?php foreach($articles as $article): ?>
                                <tr class="border-b hover:bg-gray-50"><td class="p-3"><?php echo htmlspecialchars($article['title']); ?></td><td class="p-3"><?php echo htmlspecialchars($article['category_name']); ?></td><td class="p-3 hidden md:table-cell"><?php echo htmlspecialchars($article['author']); ?></td><td class="p-3 flex space-x-4"><a href="index.php?page=articles&action=edit&id=<?php echo $article['id']; ?>" class="text-blue-500"><i class="fas fa-edit"></i></a><a href="index.php?page=articles&action=delete&id=<?php echo $article['id']; ?>" class="text-red-500" onclick="return confirm('Are you sure?')"><i class="fas fa-trash-alt"></i></a></td></tr>
                            <?php endforeach; ?>
                            </tbody></table></div>
                        <?php endif; break;

                    // --- CATEGORIES PAGE ---
                    case 'categories':
                        $action = $_GET['action'] ?? 'list';
                        if ($action == 'add' || $action == 'edit'):
                            $category = ['id' => '', 'name' => ''];
                            if ($action == 'edit' && isset($_GET['id'])) {
                                $id = intval($_GET['id']);
                                $stmt = $conn->prepare("SELECT * FROM categories WHERE id = ?");
                                $stmt->bind_param("i", $id);
                                $stmt->execute();
                                $category = $stmt->get_result()->fetch_assoc();
                            }
                ?>
                            <h1 class="text-3xl font-bold text-gray-800 mb-8"><?php echo ucfirst($action); ?> Category</h1>
                            <div class="bg-white p-6 rounded-lg shadow-md max-w-md">
                                <form action="index.php?page=categories" method="POST">
                                    <input type="hidden" name="action" value="<?php echo $action; ?>">
                                    <input type="hidden" name="id" value="<?php echo $category['id']; ?>">
                                    <div><label class="block font-semibold">Category Name</label><input type="text" name="name" value="<?php echo htmlspecialchars($category['name']); ?>" class="w-full p-2 border rounded" required></div>
                                    <div class="mt-6"><button type="submit" class="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600">Save Category</button><a href="index.php?page=categories" class="ml-4 text-gray-600">Cancel</a></div>
                                </form>
                            </div>
                        <?php else: ?>
                            <div class="flex justify-between items-center mb-8"><h1 class="text-3xl font-bold text-gray-800">Manage Categories</h1><a href="index.php?page=categories&action=add" class="bg-blue-500 text-white font-semibold px-4 py-2 rounded-lg hover:bg-blue-600"><i class="fas fa-plus mr-2"></i>Add New</a></div>
                            <?php if (isset($_SESSION['message'])): ?><div class="mb-4 p-3 rounded <?php echo $_SESSION['message_type'] == 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>"><?php echo $_SESSION['message']; unset($_SESSION['message'], $_SESSION['message_type']); ?></div><?php endif; ?>
                            <div class="bg-white p-4 rounded-lg shadow-md overflow-x-auto"><table class="w-full"><thead><tr class="border-b"><th class="p-3 text-left">Name</th><th class="p-3 text-left">Actions</th></tr></thead><tbody>
                            <?php foreach($all_categories as $category): ?>
                                <tr class="border-b hover:bg-gray-50"><td class="p-3"><?php echo htmlspecialchars($category['name']); ?></td><td class="p-3 flex space-x-4"><a href="index.php?page=categories&action=edit&id=<?php echo $category['id']; ?>" class="text-blue-500"><i class="fas fa-edit"></i></a><a href="index.php?page=categories&action=delete&id=<?php echo $category['id']; ?>" class="text-red-500" onclick="return confirm('Are you sure?')"><i class="fas fa-trash-alt"></i></a></td></tr>
                            <?php endforeach; ?>
                            </tbody></table></div>
                        <?php endif; break;

                    // --- VISITORS PAGE ---
                    case 'visitors':
                        $visitors = $conn->query("SELECT * FROM visitors ORDER BY last_visit DESC")->fetch_all(MYSQLI_ASSOC);
                ?>
                        <h1 class="text-3xl font-bold text-gray-800 mb-8">Visitor Log</h1>
                        <div class="bg-white p-4 rounded-lg shadow-md overflow-x-auto"><table class="w-full"><thead><tr class="border-b"><th class="p-3 text-left">IP Address</th><th class="p-3 text-left">Last Visit</th></tr></thead><tbody>
                        <?php foreach($visitors as $visitor): ?>
                            <tr class="border-b hover:bg-gray-50"><td class="p-3 font-mono"><?php echo htmlspecialchars($visitor['ip_address']); ?></td><td class="p-3"><?php echo date('M j, Y, g:i A', strtotime($visitor['last_visit'])); ?></td></tr>
                        <?php endforeach; ?>
                        </tbody></table></div>
                <?php break;
                endswitch; ?>
            </main>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', () => {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebar-overlay');
        const openBtn = document.getElementById('open-sidebar-btn');
        const closeBtn = document.getElementById('close-sidebar-btn');

        const openSidebar = () => {
            sidebar.classList.remove('-translate-x-full');
            overlay.classList.remove('hidden');
        };
        const closeSidebar = () => {
            sidebar.classList.add('-translate-x-full');
            overlay.classList.add('hidden');
        };

        openBtn.addEventListener('click', openSidebar);
        closeBtn.addEventListener('click', closeSidebar);
        overlay.addEventListener('click', closeSidebar);

        // Live visitor count update
        const liveVisitorsElement = document.getElementById('live-visitors');
        if (liveVisitorsElement) {
            const updateLiveCount = async () => {
                try {
                    const response = await fetch('../get_live_visitors.php');
                    const data = await response.json();
                    if (data && typeof data.live_visitors !== 'undefined') {
                        liveVisitorsElement.textContent = data.live_visitors;
                    }
                } catch (error) { console.error('Error fetching live count:', error); }
            };
            setInterval(updateLiveCount, 10000); // Update every 10 seconds
        }
    });
    </script>
</body>
</html>