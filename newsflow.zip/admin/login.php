<?php
// session_start();

// If user is already logged in, redirect them to the dashboard
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header("Location: index.php");
    exit;
}

require_once '../config.php'; // Go up one directory to find config.php
$error_message = '';

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // --- NEW: Database Authentication Logic ---
    
    // 1. Prepare a statement to find the user by username
    $stmt = $conn->prepare("SELECT * FROM admins WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        // 2. User found, now verify the password
        $user = $result->fetch_assoc();
        
        if (password_verify($password, $user['password'])) {
            // 3. Password is correct! Set session and redirect.
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_username'] = $user['username'];
            header("Location: index.php?page=dashboard");
            exit;
        }
    }

    // If we reach this point, either the user was not found or the password was incorrect.
    $error_message = 'Invalid username or password.';
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - NewsFlow</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body {
            background-image: linear-gradient(to right top, #051937, #004d7a, #008793, #00bf72, #a8eb12);
        }
    </style>
</head>
<body class="font-poppins">
    <div class="flex items-center justify-center min-h-screen">
        <div class="w-full max-w-md p-8 space-y-8 bg-white/20 backdrop-blur-sm rounded-xl shadow-lg">
            
            <div class="text-center text-white">
                <h1 class="text-3xl font-bold">News<span class="text-gray-900">Flow</span> Admin</h1>
                <p class="mt-2 text-white/80">Please sign in to continue</p>
            </div>

            <form class="mt-8 space-y-6" action="login.php" method="POST">
                <?php if ($error_message): ?>
                    <div class="p-3 bg-red-500/50 text-white rounded-lg text-center">
                        <?php echo $error_message; ?>
                    </div>
                <?php endif; ?>
                <div class="relative">
                    <span class="absolute left-3 top-3 text-gray-400"><i class="fas fa-user"></i></span>
                    <input type="text" name="username" class="w-full py-3 pl-10 pr-4 text-gray-700 bg-gray-100 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Username" required>
                </div>
                <div class="relative">
                    <span class="absolute left-3 top-3 text-gray-400"><i class="fas fa-lock"></i></span>
                    <input type="password" name="password" class="w-full py-3 pl-10 pr-4 text-gray-700 bg-gray-100 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Password" required>
                </div>
                <div>
                    <button type="submit" class="w-full py-3 font-semibold text-white bg-gray-800 rounded-lg hover:bg-gray-900 focus:outline-none">
                        Sign In
                    </button>
                </div>
            </form>
            <div class="text-center text-sm text-white/70">
                <a href="../index.php" class="hover:underline">&larr; Back to Main Site</a>
            </div>
        </div>
    </div>
</body>
</html>