<?php
// --- SETUP AND SECURITY ---
require_once '../config.php'; // Go up one directory to find config.php

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Security Check: If the user is not logged in, redirect to the login page
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

// --- DELETE LOGIC ---
// Handle deletion of a contact message
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $id_to_delete = intval($_GET['id']);
    $stmt = $conn->prepare("DELETE FROM contacts WHERE id = ?");
    $stmt->bind_param("i", $id_to_delete);
    if ($stmt->execute()) {
        $_SESSION['message'] = "Message deleted successfully!";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Error deleting message.";
        $_SESSION['message_type'] = "error";
    }
    $stmt->close();
    // Redirect back to the same page without the delete parameters
    header("Location: manage_contact.php");
    exit;
}

// --- DATA FETCHING ---
// Fetch all contact form submissions from the database
$contacts_result = $conn->query("SELECT * FROM contacts ORDER BY submitted_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Contact Messages</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        .sidebar { transition: transform 0.3s ease-in-out; }
        .modal-content { transition: transform 0.3s ease-in-out, opacity 0.3s ease-in-out; }
    </style>
</head>
<body class="bg-gray-100 font-poppins">
    <div class="flex min-h-screen">
        <!-- Overlay for mobile menu -->
        <div id="sidebar-overlay" class="fixed inset-0 bg-black/50 z-30 hidden lg:hidden"></div>

        <!-- Sidebar -->
        <aside id="sidebar" class="sidebar fixed top-0 left-0 h-full w-64 bg-gray-800 text-white flex-shrink-0 z-40 transform -translate-x-full lg:translate-x-0">
            <div class="p-5 text-2xl font-bold border-b border-gray-700 flex justify-between items-center">
                <a href="index.php">News<span class="text-blue-500">Flow</span></a>
                <button id="close-sidebar-btn" class="lg:hidden text-gray-400 hover:text-white"><i class="fas fa-times"></i></button>
            </div>
            <nav class="mt-6">
                <a href="index.php?page=dashboard" class="flex items-center px-6 py-3 text-gray-300 hover:bg-gray-700">
                    <i class="fas fa-tachometer-alt w-6"></i><span class="ml-4">Dashboard</span>
                </a>
                <a href="index.php?page=articles" class="flex items-center px-6 py-3 text-gray-300 hover:bg-gray-700">
                    <i class="fas fa-newspaper w-6"></i><span class="ml-4">Articles</span>
                </a>
                <a href="index.php?page=categories" class="flex items-center px-6 py-3 text-gray-300 hover:bg-gray-700">
                    <i class="fas fa-tags w-6"></i><span class="ml-4">Categories</span>
                </a>
                <a href="manage_contact.php" class="flex items-center px-6 py-3 bg-gray-700 text-white">
                    <i class="fas fa-envelope-open-text w-6"></i><span class="ml-4">Contact Messages</span>
                </a>
                <a href="index.php?page=visitors" class="flex items-center px-6 py-3 text-gray-300 hover:bg-gray-700">
                    <i class="fas fa-users w-6"></i><span class="ml-4">Visitors</span>
                </a>
                <div class="mt-8 border-t border-gray-700">
                    <a href="../index.php" target="_blank" class="flex items-center px-6 py-3 hover:bg-gray-700">
                        <i class="fas fa-external-link-alt w-6"></i><span class="ml-4">View Live Site</span>
                    </a>
                    <a href="index.php?action=logout" class="flex items-center px-6 py-3 hover:bg-gray-700">
                        <i class="fas fa-sign-out-alt w-6"></i><span class="ml-4">Logout</span>
                    </a>
                </div>
            </nav>
        </aside>

        <!-- Main Content Wrapper -->
        <div class="flex-1 lg:pl-64">
            <header class="bg-white shadow-md p-4 flex items-center justify-between lg:justify-end sticky top-0 z-20">
                <button id="open-sidebar-btn" class="lg:hidden text-gray-600 text-2xl">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="text-gray-600">Admin Panel</div>
            </header>

            <main class="p-6 md:p-8">
                <h1 class="text-3xl font-bold text-gray-800 mb-8">Contact Form Messages</h1>

                <?php if (isset($_SESSION['message'])): ?>
                    <div class="mb-6 p-4 rounded-lg <?php echo $_SESSION['message_type'] == 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                        <?php echo $_SESSION['message']; unset($_SESSION['message'], $_SESSION['message_type']); ?>
                    </div>
                <?php endif; ?>

                <div class="bg-white rounded-lg shadow-md">
                    <div class="overflow-x-auto">
                        <table class="w-full text-left">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="p-4 font-semibold">From</th>
                                    <th class="p-4 font-semibold">Subject</th>
                                    <th class="p-4 font-semibold hidden md:table-cell">Date</th>
                                    <th class="p-4 font-semibold">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($contacts_result && $contacts_result->num_rows > 0): ?>
                                    <?php while($contact = $contacts_result->fetch_assoc()): ?>
                                    <tr class="border-b hover:bg-gray-50">
                                        <td class="p-4">
                                            <div class="font-medium text-gray-800"><?php echo htmlspecialchars($contact['name']); ?></div>
                                            <div class="text-sm text-gray-500"><?php echo htmlspecialchars($contact['email']); ?></div>
                                        </td>
                                        <td class="p-4 text-gray-700"><?php echo htmlspecialchars($contact['subject']); ?></td>
                                        <td class="p-4 text-gray-600 hidden md:table-cell"><?php echo date('M j, Y, g:i A', strtotime($contact['submitted_at'])); ?></td>
                                        <td class="p-4 flex space-x-4">
                                            <button class="view-message-btn text-blue-500 hover:text-blue-700" title="View Message" data-id="<?php echo $contact['id']; ?>">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <a href="manage_contact.php?action=delete&id=<?php echo $contact['id']; ?>" class="text-red-500 hover:text-red-700" title="Delete" onclick="return confirm('Are you sure you want to delete this message?');">
                                                <i class="fas fa-trash-alt"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4" class="p-4 text-center text-gray-500">No contact messages found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- View Message Modal -->
    <div id="view-modal" class="fixed inset-0 bg-black/60 z-50 hidden flex items-center justify-center p-4">
        <div id="modal-content" class="modal-content bg-white w-full max-w-2xl rounded-lg shadow-xl transform scale-95 opacity-0">
            <div class="p-5 border-b flex justify-between items-center">
                <h2 class="text-xl font-bold text-gray-800" id="modal-subject"></h2>
                <button id="close-modal-btn" class="text-gray-500 hover:text-gray-800">&times;</button>
            </div>
            <div class="p-6">
                <div class="mb-4">
                    <strong class="block text-gray-500 text-sm">From:</strong>
                    <span id="modal-from"></span>
                </div>
                <div class="mb-4">
                    <strong class="block text-gray-500 text-sm">Date:</strong>
                    <span id="modal-date"></span>
                </div>
                <div>
                    <strong class="block text-gray-500 text-sm">Message:</strong>
                    <p class="mt-1 text-gray-700 whitespace-pre-wrap" id="modal-message"></p>
                </div>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', () => {
        // --- Sidebar Toggle Logic ---
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebar-overlay');
        const openBtn = document.getElementById('open-sidebar-btn');
        const closeBtn = document.getElementById('close-sidebar-btn');

        const openSidebar = () => {
            sidebar.classList.remove('-translate-x-full');
            overlay.classList.remove('hidden');
        };
        const closeSidebar = () => {
            sidebar.classList.add('-translate-x-full');
            overlay.classList.add('hidden');
        };

        openBtn.addEventListener('click', openSidebar);
        closeBtn.addEventListener('click', closeSidebar);
        overlay.addEventListener('click', closeSidebar);

        // --- View Message Modal Logic ---
        const viewModal = document.getElementById('view-modal');
        const modalContent = document.getElementById('modal-content');
        const closeModalBtn = document.getElementById('close-modal-btn');
        const viewButtons = document.querySelectorAll('.view-message-btn');

        const openModal = () => {
            viewModal.classList.remove('hidden');
            setTimeout(() => {
                modalContent.classList.remove('scale-95', 'opacity-0');
            }, 10);
        };

        const closeModal = () => {
            modalContent.classList.add('scale-95', 'opacity-0');
            setTimeout(() => {
                viewModal.classList.add('hidden');
            }, 300);
        };

        closeModalBtn.addEventListener('click', closeModal);
        viewModal.addEventListener('click', (e) => {
            if (e.target === viewModal) {
                closeModal();
            }
        });

        viewButtons.forEach(button => {
            button.addEventListener('click', async () => {
                const messageId = button.dataset.id;
                try {
                    // Fetch message details from a helper file
                    const response = await fetch(`view_message.php?id=${messageId}`);
                    const data = await response.json();

                    if (data.error) {
                        alert(data.error);
                        return;
                    }
                    
                    // Populate modal with data
                    document.getElementById('modal-subject').textContent = data.subject;
                    document.getElementById('modal-from').textContent = `${data.name} <${data.email}>`;
                    document.getElementById('modal-date').textContent = new Date(data.submitted_at).toLocaleString();
                    document.getElementById('modal-message').textContent = data.message;
                    
                    openModal();

                } catch (error) {
                    console.error('Failed to fetch message:', error);
                    alert('Could not load message details.');
                }
            });
        });
    });
    </script>
</body>
</html>