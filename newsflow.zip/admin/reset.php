<?php
// --- Standalone Password Reset Utility ---

// Go up one directory to find the config file
require_once '../config.php';

// --- Configuration ---
$target_username = 'admin'; // The username you want to reset
$new_password    = 'admin123'; // The new default password

echo "<!DOCTYPE html><html lang='en'><body style='font-family: sans-serif; padding: 20px;'>";
echo "<h1>Admin Password Reset Utility</h1>";

// 1. Securely hash the new password
$hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

echo "<p>Attempting to reset password for user: <strong>" . htmlspecialchars($target_username) . "</strong></p>";
echo "<p>New password will be: <strong>" . htmlspecialchars($new_password) . "</strong></p>";

// 2. Prepare the SQL statement to update the password
$stmt = $conn->prepare("UPDATE admins SET password = ? WHERE username = ?");

if ($stmt) {
    // 3. Bind the new hashed password and username to the statement
    $stmt->bind_param("ss", $hashed_password, $target_username);

    // 4. Execute the statement
    if ($stmt->execute()) {
        // 5. Check if a row was actually changed
        if ($stmt->affected_rows > 0) {
            echo "<p style='color: green; font-weight: bold;'>Password has been reset successfully!</p>";
        } else {
            echo "<p style='color: red; font-weight: bold;'>Error: Could not find a user with the username '" . htmlspecialchars($target_username) . "'. Please check the username.</p>";
        }
    } else {
        echo "<p style='color: red; font-weight: bold;'>Error: Failed to execute the update statement.</p>";
    }
    $stmt->close();
} else {
    echo "<p style='color: red; font-weight: bold;'>Error: Failed to prepare the SQL statement.</p>";
}

$conn->close();

echo "<hr>";
echo "<p style='color: red; font-weight: bold;'>SECURITY WARNING: Please delete this file (set_default_password.php) from your server immediately!</p>";
echo "</body></html>";

?>