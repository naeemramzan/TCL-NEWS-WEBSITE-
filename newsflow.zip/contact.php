<?php
require_once 'config.php';

// Fetch all categories for the header and footer menus
$all_categories = $conn->query("SELECT * FROM categories ORDER BY name ASC")->fetch_all(MYSQLI_ASSOC);
$message_status = '';
$message_type = '';

// Handle the form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    $stmt = $conn->prepare("INSERT INTO contacts (name, email, subject, message) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $subject, $message);
    
    if ($stmt->execute()) {
        $message_status = "Thank you! Your message has been sent successfully.";
        $message_type = "success";
    } else {
        $message_status = "Error: Something went wrong. Please try again.";
        $message_type = "error";
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - NewsFlow</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .mobile-menu { transition: transform 0.3s ease-in-out; }
    </style>
</head>
<body class="bg-gray-100 font-poppins">

    <div id="mobile-menu-container" class="fixed top-0 left-0 w-full h-full bg-black/50 z-50 hidden">
        <div id="mobile-menu" class="mobile-menu absolute top-0 right-0 h-full w-4/5 max-w-sm bg-white shadow-lg transform translate-x-full">
            <div class="p-4 flex justify-between items-center border-b">
                <a href="index.php" class="text-xl font-bold">News<span class="text-blue-600">Flow</span></a>
                <button id="close-menu-btn" class="text-gray-600 hover:text-gray-900"><i class="fas fa-times text-2xl"></i></button>
            </div>
            <nav class="mt-4">
                <a href="index.php" class="block px-4 py-3 text-gray-700 hover:bg-gray-100">Home</a>
                <a href="contact.php" class="block px-4 py-3 text-gray-700 hover:bg-gray-100 font-bold">Contact Us</a>
                <div class="px-4 pt-4 pb-2 text-sm font-semibold text-gray-400">All Categories</div>
                <?php foreach ($all_categories as $category): ?>
                    <a href="category.php?name=<?php echo urlencode(strtolower($category['name'])); ?>" class="block px-4 py-3 text-gray-700 hover:bg-gray-100"><?php echo htmlspecialchars($category['name']); ?></a>
                <?php endforeach; ?>
            </nav>
        </div>
    </div>

    <header class="bg-white shadow-md sticky top-0 z-40">
        <div class="container mx-auto px-4">
            <nav class="py-3 flex justify-between items-center">
                <a href="index.php" class="text-2xl font-bold text-gray-800">News<span class="text-blue-600">Flow</span></a>
                <div class="hidden lg:flex items-center space-x-6 text-sm font-medium">
                    <a href="index.php" class="text-gray-600 hover:text-blue-600">Home</a>
                    <?php foreach (array_slice($all_categories, 0, 4) as $category): ?>
                        <a href="category.php?name=<?php echo urlencode(strtolower($category['name'])); ?>" class="text-gray-600 hover:text-blue-600"><?php echo htmlspecialchars($category['name']); ?></a>
                    <?php endforeach; ?>
                    <a href="contact.php" class="text-blue-600 font-bold">Contact Us</a>
                </div>
                <div class="flex items-center space-x-4">
                    <div class="hidden md:flex items-center space-x-4 text-gray-500">
                        <a href="#" class="hover:text-blue-600"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="hover:text-blue-600"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="hover:text-blue-600"><i class="fab fa-instagram"></i></a>
                    </div>
                    <button id="open-menu-btn" class="lg:hidden text-gray-600 focus:outline-none text-2xl"><i class="fas fa-bars"></i></button>
                </div>
            </nav>
        </div>
    </header>

    <main class="container mx-auto px-4 py-12 md:py-20">
        <div class="bg-white max-w-6xl mx-auto p-8 md:p-12 rounded-2xl shadow-xl overflow-hidden">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                
                <div class="lg:block">
                    <img src="img/contact.jpeg" alt="Contact Us" class="w-full h-full object-cover rounded-xl">
                </div>

                <div>
                    <div class="text-center lg:text-left mb-10">
                        <h1 class="text-4xl md:text-5xl font-bold font-serif text-gray-800">Get In Touch</h1>
                        <p class="text-gray-500 mt-2">We'd love to hear from you. Please fill out the form.</p>
                    </div>
                    
                    <?php if ($message_status): ?>
                        <div class="mb-6 p-4 rounded-lg text-center <?php echo $message_type == 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                            <?php echo $message_status; ?>
                        </div>
                    <?php endif; ?>

                    <form action="contact.php" method="POST" class="space-y-6">
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                            <div>
                                <label for="name" class="block text-gray-700 font-semibold mb-2">Your Name</label>
                                <input type="text" name="name" id="name" class="w-full px-4 py-2 bg-gray-50 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                            </div>
                            <div>
                                <label for="email" class="block text-gray-700 font-semibold mb-2">Your Email</label>
                                <input type="email" name="email" id="email" class="w-full px-4 py-2 bg-gray-50 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                            </div>
                        </div>
                        <div>
                            <label for="subject" class="block text-gray-700 font-semibold mb-2">Subject</label>
                            <input type="text" name="subject" id="subject" class="w-full px-4 py-2 bg-gray-50 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                        </div>
                        <div>
                            <label for="message" class="block text-gray-700 font-semibold mb-2">Message</label>
                            <textarea name="message" id="message" rows="5" class="w-full px-4 py-2 bg-gray-50 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required></textarea>
                        </div>
                        <div class="text-center lg:text-left">
                            <button type="submit" class="bg-blue-600 text-white font-semibold px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors">Send Message</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </main>

    <footer class="bg-gray-800 text-white mt-12">
        <div class="container mx-auto px-4 py-12">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 text-center md:text-left">
                <div class="md:col-span-1"><h3 class="text-xl font-bold mb-4">News<span class="text-blue-500">Flow</span></h3><p class="text-gray-400 text-sm">Your reliable source for the latest news.</p></div>
                <div><h3 class="text-lg font-semibold mb-4">Quick Links</h3><ul class="space-y-2 text-sm"><li class="text-gray-400 hover:text-white"><a href="index.php">Home</a></li><li class="text-gray-400 hover:text-white"><a href="contact.php">Contact Us</a></li><li class="text-gray-400 hover:text-white"><a href="#">About Us</a></li></ul></div>
                <div><h3 class="text-lg font-semibold mb-4">Follow Us</h3><div class="flex justify-center md:justify-start space-x-6"><a href="#" class="text-xl text-gray-400 hover:text-white"><i class="fab fa-facebook-f"></i></a><a href="#" class="text-xl text-gray-400 hover:text-white"><i class="fab fa-twitter"></i></a><a href="#" class="text-xl text-gray-400 hover:text-white"><i class="fab fa-instagram"></i></a></div></div>
            </div>
            <div class="border-t border-gray-700 mt-8 pt-6 text-center text-sm text-gray-500"><p>&copy; <?php echo date("Y"); ?> NewsFlow. All Rights Reserved.</p></div>
        </div>
    </footer>

    <script>
    document.addEventListener('DOMContentLoaded', () => {
        const openBtn = document.getElementById('open-menu-btn');
        const closeBtn = document.getElementById('close-menu-btn');
        const menuContainer = document.getElementById('mobile-menu-container');
        const menu = document.getElementById('mobile-menu');

        openBtn.addEventListener('click', () => {
            menuContainer.classList.remove('hidden');
            setTimeout(() => menu.style.transform = 'translateX(0)', 10);
        });

        const closeMenu = () => {
            menu.style.transform = 'translateX(100%)';
            setTimeout(() => menuContainer.classList.add('hidden'), 300);
        };
        closeBtn.addEventListener('click', closeMenu);
        menuContainer.addEventListener('click', (e) => { if (e.target === menuContainer) closeMenu(); });
    });
    </script>
</body>
</html>