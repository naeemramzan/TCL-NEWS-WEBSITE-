<?php
require_once 'config.php';

// --- Fetch ALL Categories for Navbar ---
$categories_result_for_search = $conn->query("SELECT * FROM categories ORDER BY name ASC");
$all_categories_for_search = $categories_result_for_search->fetch_all(MYSQLI_ASSOC);

// --- Handle Search Query ---
$search_query = '';
$search_results = [];
if (isset($_GET['query']) && !empty(trim($_GET['query']))) {
    $search_query = trim($_GET['query']);
    
    $stmt = $conn->prepare("
        SELECT a.*, c.name as category_name 
        FROM articles a
        JOIN categories c ON a.category_id = c.id
        WHERE a.title LIKE ? OR a.content LIKE ?
        ORDER BY a.created_at DESC
    ");
    $search_term = "%" . $search_query . "%";
    $stmt->bind_param("ss", $search_term, $search_term);
    $stmt->execute();
    $result = $stmt->get_result();
    $search_results = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results for "<?php echo htmlspecialchars($search_query); ?>"</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = { theme: { extend: { fontFamily: { poppins: ['Poppins', 'sans-serif'], serif: ['Playfair Display', 'serif'] } } } }
    </script>
</head>
<body class="bg-gray-100 font-poppins">

    <header class="bg-white shadow-md sticky top-0 z-50">
        <div class="container mx-auto px-4">
            <nav class="py-3 flex justify-between items-center">
                <a href="index.php" class="text-2xl font-bold text-gray-800">News<span class="text-blue-600">Flow</span></a>
                 <div class="hidden md:flex flex-1 justify-center items-center mx-4">
                     <div class="flex items-center space-x-4 text-sm">
                        <a href="index.php" class="text-gray-600 hover:text-blue-600">Home</a>
                         <?php foreach (array_slice($all_categories_for_search, 0, 14) as $category): ?>
                            <a href="category.php?name=<?php echo urlencode(strtolower($category['name'])); ?>" class="text-gray-600 hover:text-blue-600"><?php echo htmlspecialchars($category['name']); ?></a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <form action="search.php" method="GET" class="hidden md:flex items-center relative">
                        <input type="search" name="query" value="<?php echo htmlspecialchars($search_query); ?>" placeholder="Search..." class="border rounded-full py-1.5 px-4 text-sm w-40">
                        <button type="submit" class="absolute right-3 text-gray-400"><i class="fas fa-search"></i></button>
                    </form>
                    <button id="mobile-menu-button" class="md:hidden text-gray-600"><i class="fas fa-bars text-xl"></i></button>
                </div>
            </nav>
        </div>
    </header>

    <main class="container mx-auto px-4 py-12 min-h-screen">
        <h1 class="text-4xl font-bold font-serif text-gray-800 mb-8">
            Search Results for: <span class="text-blue-600">"<?php echo htmlspecialchars($search_query); ?>"</span>
        </h1>

        <?php if (!empty($search_results)): ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <?php foreach ($search_results as $article): ?>
                    <div class="bg-white rounded-lg shadow-md overflow-hidden group">
                        <a href="article.php?id=<?php echo $article['id']; ?>" class="block">
                            <img src="uploads/<?php echo htmlspecialchars($article['image']); ?>" onerror="this.onerror=null;this.src='https://placehold.co/400x250/e2e8f0/4a5568?text=Image';" alt="<?php echo htmlspecialchars($article['title']); ?>" class="w-full h-40 object-cover">
                            <div class="p-4">
                                <h3 class="font-bold text-gray-800 h-12 group-hover:underline"><?php echo htmlspecialchars($article['title']); ?></h3>
                                <div class="text-xs text-gray-500 mt-2">By <?php echo htmlspecialchars($article['author']); ?></div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php elseif (!empty($search_query)): ?>
            <div class="text-center py-20">
                <h2 class="text-2xl font-semibold text-gray-700">No Articles Found</h2>
                <p class="text-gray-500 mt-2">Sorry, we couldn't find any articles matching your search. Please try again with different keywords.</p>
            </div>
        <?php else: ?>
             <div class="text-center py-20">
                <h2 class="text-2xl font-semibold text-gray-700">Please Enter a Search Query</h2>
                <p class="text-gray-500 mt-2">Use the search bar above to find articles on our site.</p>
            </div>
        <?php endif; ?>
    </main>
    
    <footer class="bg-gray-800 text-white">
        <div class="container mx-auto px-4 py-8">
             <p class="text-center text-sm text-gray-500">&copy; <?php echo date("Y"); ?> NewsFlow. All Rights Reserved.</p>
        </div>
    </footer>
</body>
</html>